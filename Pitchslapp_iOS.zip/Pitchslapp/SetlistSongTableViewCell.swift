//
//  SetlistSongTableViewCell.swift
//  Pitchslapp
//
//  Created by Zachary Stecker on 5/3/16.
//  Copyright © 2016 Social Coderz. All rights reserved.
//

import UIKit

class SetlistSongTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var soloLabel: UILabel!
    @IBOutlet weak var keyLabel: UILabel!
    @IBOutlet weak var indexLabel: UILabel!
    

}
