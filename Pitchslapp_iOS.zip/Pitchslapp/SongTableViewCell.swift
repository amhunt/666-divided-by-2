//
//  SongTableViewCell.swift
//  Pitchslapp
//
//  Created by Zachary Stecker on 3/29/16.
//  Copyright © 2016 Social Coderz. All rights reserved.
//

import UIKit

class SongTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var soloLabel: UILabel!
    @IBOutlet weak var keyLabel: UILabel!
    
    
}
